﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Drawing;

namespace WheaterAPI.Classes
{
    class Database
    {

        public DataType GetQueryValue(valueType ValueType, string[] _query, string[] parameters, string[] parameterNames)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(GetConnection().ConnectionString))
                {
                    connection.Open();
                    return ExecuteQuery(ValueType, parameters, parameterNames, _query, connection);
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
                return null;
            }
        }
        public void InsertQuery(string _query, string[] parameters, string[] parameterNames)
        {
            try
            {
                using(SqlConnection connection = new SqlConnection(GetConnection().ConnectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(_query, connection))
                    {
                        if (parameters.Length != 0 || parameterNames.Length != 0)
                        {
                            GetParameters(parameters, parameterNames, command);
                        }
                        command.CommandText = _query;
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        #region PrivateMethods
        private SqlConnectionStringBuilder GetConnection()
        {
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "salty.database.windows.net";
                builder.UserID = "saltyboy";
                builder.Password = "Snsd11586!";
                builder.InitialCatalog = "PT12-Database";

                return builder;
            }
            catch
            {
                return null;
            }
        }
        private DataType ExecuteQuery(valueType ValueType, string[] parameters, string[] parameterNames, String[] sqlArray, SqlConnection connection)
        {
            foreach (string sql in sqlArray)
            {
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    if(parameters != null || parameterNames != null)
                    {
                        GetParameters(parameters, parameterNames, command);
                    }
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {                        
                        if (ValueType.Equals(valueType.dataTable))
                        {
                            DataTable datatable = new DataTable();
                            datatable.Load(reader);
                            return new DataType(datatable);
                        }
                        else if (ValueType.Equals(valueType.seedCoordinatesList))
                        {
                            return SetCoordinates(reader);
                        }
                        else if (ValueType.Equals(valueType.String))
                        {
                            return SetString(reader);
                        }
                        else if (ValueType.Equals(valueType.wordList))
                        {
                            return SetWordList(reader);
                        }
                        else if (ValueType.Equals(valueType.weatherMessage))
                        {
                            return SetWeatherMessage(reader);
                        }
                    }
                    else
                    {
                        reader.Close();
                    }
                }
            }
            return null;
        }
        private void GetParameters(string[] parameters, string[] parameterNames, SqlCommand command)
        {
            if(command.Parameters.Count != 0)
            {
                command.Parameters.Clear();
            }
            if (parameters.Length == parameterNames.Length)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    string paraname = parameterNames[i];
                    string para = parameters[i];
                    command.Parameters.AddWithValue(paraname, para);
                }
            }
        }
        #region dataTypeMethods
        private DataType SetCoordinates(SqlDataReader reader)
        {
            using (reader)
            {
                List<Point> seedcoordsList = new List<Point>();
                while (reader.Read())
                {
                    Point seedCoordinates = new Point(reader.GetInt32(0), reader.GetInt32(1));
                    seedcoordsList.Add(seedCoordinates);
                }
                return new DataType(seedcoordsList);
            }
        }
        private DataType SetString(SqlDataReader reader)
        {
            using (reader)
            {
                while (reader.Read())
                {
                    return new DataType(reader.GetValue(0).ToString());
                }
                return null;
            }
        }
        private DataType SetWordList(SqlDataReader reader)
        {
            using (reader)
            {
                List<string> wordList = new List<string>();
                while (reader.Read())
                {
                    wordList.Add(reader.GetString(0));
                }
                return new DataType(wordList);
            }
        }
        private DataType SetWeatherMessage(SqlDataReader reader)
        {
            using (reader)
            {
                List<WeatherMessage> weatherMessage = new List<WeatherMessage>();
                while (reader.Read())
                {
                    weatherMessage.Add(new WeatherMessage(reader.GetInt32(0), reader.GetDecimal(3), reader.GetDecimal(4), reader.GetDecimal(5), reader.GetDecimal(6), reader.GetDateTime(7)));
                }
                return new DataType(weatherMessage);
            }
        }
        #endregion
        #endregion

        public enum valueType
        {
            dataTable,
            seedCoordinatesList,
            String,
            wordList,
            weatherMessage,
        }
    }
}
