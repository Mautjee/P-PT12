﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheaterAPI.Classes
{
    class Querry
    {
        public class Weather
        {
            public static string Delete()
            {
                return "DELETE FROM WeatherAPI WHERE WeatherID = @weatherid; ";
            }
            public static string[] GetAmountOfRows()
            {
                return new string[] { "SELECT COUNT(WeatherID) FROM WeatherAPI" };
            }
            public static string[] GetLatest()
            {
                return new string[] { "SELECT * FROM WeatherAPI WHERE WeatherID = @weatherid" };
            }
            public static string[] GetLatestDate()
            {
                return new string[] { "SELECT date FROM WeatherAPI WHERE WeatherID IN( SELECT MAX(WeatherID) FROM WeatherAPI )" };
            }
            public static string[] GetWeatherID()
            {
                return new string[] { "SELECT WeatherID FROM Robot WHERE UserID = @userid" };
            }
            public static string Insert()
            {
                return "INSERT INTO WeatherAPI VALUES(@weatherID, @lon, @lat, @weatherTemperature, @windspeed, @pressure, @humidity, @date)";
            }
        }
        public class Users
        {
            //nieuwe user toevoegen
            //inloggen (username and password)
            public static string[] CheckLogin()
            {
                return new string[] { "SELECT UserID FROM Userr WHERE Username = @username AND Password = @password; " };
            }
        }
        public class Robot
        {
            //nieuwe robot toevoegen aan user
            //insert temp (naar tabel Temperature)
            public static string[] GetRobots()
            {
                return new string[] { "SELECT Name FROM Robot WHERE UserID = @userid;" };
            }
        }
        public class Saline
        {

        }
    }
    class Parameter
    {
        public class Weather
        {
            public static string[] ID()
            {
                return new string[] { "@weatherid" };
            }
            public static string[] Insert()
            {
                return new string[] { "@weatherID", "@lon", "@lat", "@weatherTemperature", "@windspeed", "@pressure", "@humidity", "@date" };
            }
        }
        public class User
        {
            public static string[] CheckLogin()
            {
                return new string[] { "@username", "@password" };
            }
        }
        public class Robot
        {
            public static string[] GetNames()
            {
                return new string[] { "@userid" };
            }
        }
    }
}
