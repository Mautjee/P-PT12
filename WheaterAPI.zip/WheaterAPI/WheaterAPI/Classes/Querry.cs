﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheaterAPI.Classes
{
    class Querry
    {
        public class Weather
        {
            public static string Delete()
            {
                return "DELETE FROM WeatherAPI WHERE WeatherID = @weatherid; ";
            }
            public static string[] GetAmountOfRows()
            {
                return new string[] { "SELECT COUNT(WeatherID) FROM WeatherAPI" };
            }
            public static string[] GetLatest()
            {
                return new string[] { "SELECT * FROM WeatherAPI WHERE WeatherID = @weatherid" };
            }
            public static string[] GetLatestDate()
            {
                return new string[] { "SELECT date FROM WeatherAPI WHERE WeatherID IN( SELECT MAX(WeatherID) FROM WeatherAPI )" };
            }
            public static string[] GetHighestID()
            {
                return new string[] { "SELECT MAX(WeatherID) FROM WeatherAPI" };
            }
            public static string Insert()
            {
                return "INSERT INTO WeatherAPI VALUES(@weatherID, @weatherTemperature, @windspeed, @pressure, @humidity, @date)";
            }
        }
    }
    class Parameter
    {
        public class Weather
        {
            public static string[] ID()
            {
                return new string[] { "@weatherid" };
            }
            public static string[] Insert()
            {
                return new string[] { "@weatherID", "@weatherTemperature", "@windspeed", "@pressure", "@humidity", "@date" };
            }
        }
    }
}
