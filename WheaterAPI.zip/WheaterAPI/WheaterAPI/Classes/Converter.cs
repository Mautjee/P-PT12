﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheaterAPI.Classes
{
    class Converter
    {
        public static string GetDecimal(double val)
        {
            return Convert.ToDecimal(val).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);
        }
    }
}
