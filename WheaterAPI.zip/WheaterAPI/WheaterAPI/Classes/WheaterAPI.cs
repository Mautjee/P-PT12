﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Newtonsoft.Json;
using System.Net;

namespace WheaterAPI.Classes
{
    class WheaterAPI
    {
        public class coord
        {
            public double lon { get; set; }
            public double lat { get; set; }
        }
        public class weather
        {
            public int id { get; set; }
            public string main { get; set; }
            public string description { get; set; }
            public string icon { get; set; }
        }
        public class main
        {
            public double temp { get; set; }
            public double pressure { get; set; }
            public double humidity { get; set; }
        }
        public class wind
        {
            public double speed { get; set; }
        }
        public class sys
        {
            public string country { get; set; }
        }
        public class root
        {
            public string name { get; set; }
            public sys sys { get; set; }
            public double dt { get; set; }
            public wind wind { get; set; }
            public main main { get; set; }
            public coord coord { get; set; }
            public List<weather> weather { get; set; }
        }

        public BitmapImage GetIcon(string iconNumber)
        {
            BitmapImage icon = new BitmapImage();
            icon.BeginInit();
            icon.UriSource = new Uri("http://openweathermap.org/img/w/" + iconNumber + ".png");
            icon.EndInit();
            return icon;
        }
        public void InsertWeather(string currentday, Database database, WheaterAPI.root api, int MaxDBRows, int amountOfRows)
        {
            string LatestWeatherID;
            //het is de volgende dag -> insert nieuw weer OF de eerste dag
            if (currentday != "")
            {
                LatestWeatherID = (Convert.ToInt32(GetLatestWeatherID(database)) + 1).ToString();
            }
            else
            {
                LatestWeatherID = "1";
            }
            //Zijn er al 3 items in de tabel??
            if (amountOfRows == MaxDBRows)
            {
                //verwijder de eerste tabel
                string[] DParameterNames = { (Convert.ToInt16(LatestWeatherID) - 2).ToString() };
                database.InsertQuery(Classes.Querry.Weather.Delete(), DParameterNames, Classes.Parameter.Weather.ID());
            }
            //maak een nieuw row aan
            string[] ParameterNames = { LatestWeatherID, Convert.ToInt32(api.main.temp - 273).ToString(), Converter.GetDecimal(api.wind.speed), Converter.GetDecimal(api.main.pressure).ToString(), Converter.GetDecimal(api.main.humidity).ToString(), DateTime.Today.ToString() };
            database.InsertQuery(Classes.Querry.Weather.Insert(), ParameterNames, Classes.Parameter.Weather.Insert());
        }
        public string GetLatestWeatherID(Database database)
        {
            return database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetHighestID(), new string[0], new string[0]).value;
        }
        public root GetWheater(string City, string AppId)
        {
            using (WebClient web = new WebClient())
            {
                //url for the API
                string url = string.Format("http://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}&untis=metric", City, AppId);
                //Get the Json file with wheater information
                var json = web.DownloadString(url);
                root output = JsonConvert.DeserializeObject<root>(json);
                return output;
                //CountryLabel.Text = string.Format("{0}", API.sys.country);
            }
        }
    }
}
