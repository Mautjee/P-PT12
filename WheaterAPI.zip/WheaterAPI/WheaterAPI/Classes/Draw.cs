﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WheaterAPI.Classes
{
    class Draw
    {
        public drawinglist UpdateDrawings(int AmountOfRows, List<WeatherMessage> weathervalues)
        {
            List<UIElement> Tempobjects = new List<UIElement>();
            List<UIElement> Humobjects = new List<UIElement>();
            List<UIElement> Pressobjects = new List<UIElement>();

            decimal[] tempvalues = new decimal[AmountOfRows];
            decimal[] humvalues = new decimal[AmountOfRows];
            decimal[] pressurevalues = new decimal[AmountOfRows];
            for (int i = 0; i < weathervalues.Count; i++)
            {
                tempvalues.SetValue(weathervalues[i].weatherTemperature, i);
                humvalues.SetValue(weathervalues[i].Humidity, i);
                pressurevalues.SetValue(weathervalues[i].Pressure, i);
            }
            Tempobjects.AddRange(DrawLine(tempvalues, Brushes.DarkBlue, 50, 1, Convert.ToInt32(tempvalues[0]), "°C"));
            Humobjects.AddRange(DrawLine(humvalues, Brushes.DarkGreen, 10, 0.5, Convert.ToInt32(humvalues[0]), "%"));
            Pressobjects.AddRange(DrawLine(pressurevalues, Brushes.DarkViolet, 10, 0.08, Convert.ToInt32(pressurevalues[0]), "hpa"));

            return new drawinglist(Tempobjects, Humobjects, Pressobjects);
        }
        private List<UIElement> DrawLine(decimal[] values, SolidColorBrush brush, int DefaultYPosition, double mulitplier, int latestypos, string unit)
        {
            int xSteps = 50;
            int latestx = 0;
            int latesty = latestypos;
            List<UIElement> objects = new List<UIElement>();
            objects.AddRange(new UIElement[] { MakeEllipse(5, 5, latestx, (latesty + DefaultYPosition) * mulitplier), MakeText(values[0].ToString(), unit, latestx, (latesty + DefaultYPosition) * mulitplier) });

            for (int i = 1; i < values.Length; i++)
            {
                double x = latestx + xSteps;
                double y = (Convert.ToInt32(values[i]) + DefaultYPosition) * mulitplier;

                Line line = MakeLine(brush, latestx, x, (latesty + DefaultYPosition) * mulitplier, y);
                Ellipse ellipse = MakeEllipse(5, 5, x, y);
                TextBlock text = MakeText(values[i].ToString(), unit, x, y + 2);

                objects.AddRange(new UIElement[]{ line, ellipse, text });

                latestx += xSteps;
                latesty = Convert.ToInt32(values[i]);
            }
            return objects;
        }
        private void SetPosition(UIElement element, double x, double y)
        {
            Canvas.SetLeft(element, x);
            Canvas.SetTop(element, y);
        }
        private Ellipse MakeEllipse(int width, int height, double x, double y)
        {
            Ellipse ellipse = new Ellipse();
            ellipse.Fill = Brushes.Black;
            ellipse.Width = width;
            ellipse.Height = height;
            SetPosition(ellipse, x, y - (ellipse.Height / 2));
            return ellipse;
        }
        private TextBlock MakeText(string value, string unit, double x, double y)
        {
            TextBlock text = new TextBlock();
            text.Text = value.ToString() + unit;
            text.FontSize = 10;
            ScaleTransform myScaleTransform = new ScaleTransform();
            myScaleTransform.ScaleY = -1;
            text.RenderTransform = myScaleTransform;
            SetPosition(text, x, y - 5);
            return text;
        }
        private Line MakeLine(SolidColorBrush brush, double x1, double x2, double y1, double y2)
        {

            Line line = new Line();
            line.Stroke = brush;
            line.X1 = x1;
            line.Y1 = y1;
            line.X2 = x2;
            line.Y2 = y2;
            return line;
        }
    }
}
