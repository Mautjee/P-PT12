﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WheaterAPI.Classes
{
    class Draw
    {
        public static List<Line> UpdateDrawings(int AmountOfRows, List<WeatherMessage> weathervalues)
        {
            List<Line> lines = new List<Line>();
            decimal[] tempvalues = new decimal[AmountOfRows];
            decimal[] humvalues = new decimal[AmountOfRows];
            decimal[] pressurevalues = new decimal[AmountOfRows];
            for (int i = 0; i < weathervalues.Count; i++)
            {
                tempvalues.SetValue(weathervalues[i].weatherTemperature, i);
                humvalues.SetValue(weathervalues[i].Humidity, i);
                pressurevalues.SetValue(weathervalues[i].Pressure, i);
            }
            lines.AddRange(DrawLine(tempvalues, Brushes.DarkBlue, 0, 1));
            lines.AddRange(DrawLine(humvalues, Brushes.DarkGreen, 10, 0.5));
            lines.AddRange(DrawLine(pressurevalues, Brushes.DarkViolet, 15, 0.1));

            return lines;
        }
        private static List<Line> DrawLine(decimal[] values, SolidColorBrush brush, int DefaultYPosition, double mulitplier)
        {
            int xSteps = 50;
            int latestx = 0;
            int latesty = 0;
            List<Line> lines = new List<Line>();
            foreach (decimal value in values)
            {
                Line line = new Line();
                line.Stroke = brush;
                line.X1 = latestx;
                line.Y1 = (latesty + DefaultYPosition) * mulitplier;
                line.X2 = (latestx + xSteps);
                line.Y2 = (Convert.ToInt32(value) + DefaultYPosition) * mulitplier;
                lines.Add(line);
                latestx += xSteps;
                latesty += Convert.ToInt32(value);
            }
            return lines;
        }
    }
}
