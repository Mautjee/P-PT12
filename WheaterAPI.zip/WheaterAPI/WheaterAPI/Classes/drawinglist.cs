﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheaterAPI.Classes
{
    class drawinglist
    {
        private List<UIElement> tempobjects = new List<UIElement>();
        private List<UIElement> humobjects = new List<UIElement>();
        private List<UIElement> pressobjects = new List<UIElement>();

        public List<UIElement> tempObjects { get { return tempobjects; } }
        public List<UIElement> humObjects { get { return humobjects; } }
        public List<UIElement> pressObjects { get { return pressobjects; } }

        public drawinglist (List<UIElement> tempObjects, List<UIElement> humObjects, List<UIElement> pressObjects)
        {
            tempobjects = tempObjects; humobjects = humObjects; pressobjects = pressObjects;
        }
    }
}
