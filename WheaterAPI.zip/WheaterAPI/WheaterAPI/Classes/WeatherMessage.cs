﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheaterAPI.Classes
{
    class WeatherMessage
    {
        private int weatherid;
        private decimal weathertemperature;
        private decimal windspeed;
        private decimal pressure;
        private decimal humidity;
        private DateTime date;

        public int weatherID { get { return weatherid; } }
        public decimal weatherTemperature { get { return weathertemperature; } }
        public decimal windSpeed { get { return windspeed; } }
        public decimal Pressure { get { return pressure; } }
        public decimal Humidity { get { return humidity; } }
        public DateTime Date { get { return date; } }

        public WeatherMessage(int weatherID, decimal weatherTemperature, decimal windSpeed, decimal Pressure, decimal Humidity, DateTime Date)
        {
            weatherid = weatherID; weathertemperature = weatherTemperature; windspeed = windSpeed; pressure = Pressure; humidity = Humidity; date = Date;
        }
    }
}
