﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheaterAPI.Classes
{
    class Robot
    {
        public void CheckCheckIfRobotSprinkle(List<WeatherMessage> weathervalues, Classes.WheaterAPI.root api)
        {
            //als de temperatuur onder nul is en hoge luchtvogtigheid of regen zelfs dan moet de robot gaan rijden
            if (Convert.ToInt32(weathervalues[0].weatherTemperature) <= 0)
            {
                //koude temperetuur
                if (Convert.ToInt32(weathervalues[0].Humidity) >= 80)
                {
                    //hoge luchtvogtigheid
                    //dus de robot moet rijden
                }
            }

            //ook moet de robot rijden als het sneeuwt
            foreach (var wh in api.weather)
            {
                if (wh.id >= 600 && wh.id <= 622)
                {
                    //its snowing -> drive the robot
                }
            }
        }
    }
}
