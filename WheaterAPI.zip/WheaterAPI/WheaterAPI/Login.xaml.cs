﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WheaterAPI
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {

        Classes.Database database = new Classes.Database();
        public Login()
        {
            InitializeComponent();
        }
        private void SubmitB_Click(object sender, RoutedEventArgs e)
        {
            if(UserTB.Text != "" && PasswordTB.Password != "")
            {
                string[] ParameterNames =
                {
                    UserTB.Text,
                    PasswordTB.Password
                };
                string userID = database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Users.CheckLogin(), ParameterNames, Classes.Parameter.User.CheckLogin()).value;
                if(userID != "" || userID != null)
                {
                    //Correct login
                    main MainWindow = new main(userID);
                    Application.Current.MainWindow = MainWindow;
                    MainWindow.Show();
                    Close();
                }
            }
            else
            {
                UpdateInfoLabel();
            }
        }
        private void UpdateInfoLabel()
        {
            string[] dynstring = new string[2];
            int index = 0;
            if (UserTB.Text == "")
            {
                dynstring.SetValue("username field", index);
                index++;
            }
            if (PasswordTB.Password == "")
                dynstring.SetValue("password field", index);
            infoLabel.Content = "You forgot to fill the ";
            for (int i = 0; i < dynstring.Length; i++)
            {
                if (i != 0)
                    infoLabel.Content += "and ";
                infoLabel.Content += dynstring[i];
            }
        }
        private void SubB_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
