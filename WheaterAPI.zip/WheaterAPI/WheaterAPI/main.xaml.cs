﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net;
using System.Globalization;
using Newtonsoft.Json;

namespace WheaterAPI
{
    /// <summary>
    /// Interaction logic for main.xaml
    /// </summary>
    public partial class main : Window
    {
        private int FormRefreshRate = 60;
        private int WheaterID = 1;
        private string LatestWeatherID;
        private DateTime RefreshTime;
        #region WheaterInfo
        const string APPID = "1b5d684d0770c40eccf2c841635621e2";
        string CityName = "Eindhoven";
        #endregion
        #region DrawVars
        int xSteps = 10;
        int latestx;
        int latesty;
        #endregion
        #region classes
        private Classes.WheaterAPI.root api = new Classes.WheaterAPI.root();
        private Classes.Database database = new Classes.Database();
        #endregion

        public main()
        {
            InitializeComponent();
            DrawLine(20);
            //Get Wheater and parse it into the labels
            api = GetWheater(CityName, APPID);

            #region UpdateForm
            UpdateForm(null, EventArgs.Empty);
            Timer timer = new Timer();
            timer.Interval = (FormRefreshRate * 6000);
            timer.Tick += new EventHandler(UpdateForm);
            timer.Start();
            #endregion

            CheckIfRobotSprinkle();
        }
        private void UpdateForm(object sender, EventArgs e)
        {
            #region UpdateWindow
            WhereLabel.Content = "Where: " + api.sys.country + " " + api.name;
            StatusLabel.Content = "Status: ";
            foreach (var wheatdisc in api.weather)
            {
                StatusLabel.Content += wheatdisc.description + ", ";
            }
            APITempLabel.Content = "Temperatuur: " + Convert.ToInt32(api.main.temp - 273) + "°C";
            APIHumLabel.Content = "Humidity: " + api.main.humidity + "%";
            APIPressLabel.Content = "Pressure: " + api.main.pressure + "hpa";
            #endregion

            #region SetIcon
            BitmapImage icon = new BitmapImage();
            icon.BeginInit();
            icon.UriSource = new Uri("http://openweathermap.org/img/w/" + api.weather[0].icon + ".png");
            icon.EndInit();
            WeatherIcon.Source = icon;
            #endregion

            #region UpdateWeather
            if(DateTime.Now == RefreshTime)
            {
                string temp = GetDecimal(api.main.temp);
                string wind = GetDecimal(api.wind.speed);
                string pressure = GetDecimal(api.main.pressure);
                string humidity = GetDecimal(api.main.humidity);
                string querry = "INSERT INTO WeatherAPI VALUES (" + WheaterID + ", " + temp + ", " + wind + ", " + pressure + ", " + humidity + ")";
                database.InsertQuery(querry, null, null);
            }
            #endregion

            string CurrentDay;
            try
            {
                CurrentDay = database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetLatestDate(), new string[0], new string[0]).value;
            }
            catch
            {
                CurrentDay = "";
            }
            string today = DateTime.Today.ToString("M/d/yyyy") + " 00:00:00";
            if (CurrentDay == "" || CurrentDay != today)
            {
                //het is de volgende dag -> insert nieuw weer OF de eerste dag
                if(CurrentDay != "")
                {
                    LatestWeatherID = (Convert.ToInt32(GetLatestWeatherID()) + 1).ToString();
                }
                else
                {
                    LatestWeatherID = "1";
                }
                //Zijn er al 3 items in de tabel??
                if (database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetAmountOfRows(), new string[0], new string[0]).value == "3")
                {
                    //verwijder de eerste tabel
                    string[] DParameterNames = { (Convert.ToInt16(LatestWeatherID) - 2).ToString() };
                    database.InsertQuery(Classes.Querry.Weather.Delete(), DParameterNames, Classes.Parameter.Weather.ID());
                }
                //maak een nieuw row aan
                string[] ParameterNames = { LatestWeatherID, Convert.ToInt32(api.main.temp - 273).ToString(), GetDecimal(api.wind.speed).ToString(), GetDecimal(api.main.pressure).ToString(), GetDecimal(api.main.humidity).ToString(), DateTime.Today.ToString() };
                database.InsertQuery(Classes.Querry.Weather.Insert(), ParameterNames, Classes.Parameter.Weather.Insert());
            }

            CheckIfRobotSprinkle();
        }
        private void UpdatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshTime = (DateTime)UpdatePicker.SelectedDate;
        }
        private void CheckIfRobotSprinkle()
        {
            //als de temperatuur onder nul is en hoge luchtvogtigheid of regen zelfs dan moet de robot gaan rijden
            if(LatestWeatherID == null)
            {
                LatestWeatherID = GetLatestWeatherID();
            }
            string[] ParameterNames = { LatestWeatherID };
            List<Classes.WeatherMessage> weathervalues = database.GetQueryValue(Classes.Database.valueType.weatherMessage, Classes.Querry.Weather.GetLatest(), ParameterNames, Classes.Parameter.Weather.ID()).weatherList;
            if(Convert.ToInt32(weathervalues[0].weatherTemperature) <= 0)
            {
                //koude temperetuur
                if(Convert.ToInt32(weathervalues[0].Humidity) >= 80)
                {
                    //hoge luchtvogtigheid
                    //dus de robot moet rijden
                }
            }

            //ook moet de robot rijden als het sneeuwt
            foreach (var wh in api.weather)
            {
                if(wh.id >= 600 && wh.id <= 622)
                {
                    //its snowing -> drive the robot
                }
            }
        }
        private string GetLatestWeatherID()
        {
            return database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetHighestID(), new string[0], new string[0]).value;
        }
        private void DrawLine(int temp)
        {
            Line line = new Line();
            line.Stroke = Brushes.DarkBlue;
            line.X1 = latestx;
            line.Y1 = latesty;
            line.X2 = latestx + xSteps;
            line.Y2 = temp;
            mycanvas.Children.Add(line);
        }
        private Classes.WheaterAPI.root GetWheater(string City, string AppId)
        {
            using (WebClient web = new WebClient())
            {
                //url for the API
                string url = string.Format("http://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}&untis=metric", City, AppId);
                //Get the Json file with wheater information
                var json = web.DownloadString(url);
                Classes.WheaterAPI.root output = JsonConvert.DeserializeObject<Classes.WheaterAPI.root>(json);
                return output;
                //CountryLabel.Text = string.Format("{0}", API.sys.country);
            }
        }
        private string GetDecimal (double val)
        {
            return Convert.ToDecimal(val).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);
        }
    }
}
