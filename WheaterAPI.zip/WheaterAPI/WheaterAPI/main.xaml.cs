﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net;
using System.Globalization;
using Newtonsoft.Json;

namespace WheaterAPI
{
    /// <summary>
    /// Interaction logic for main.xaml
    /// </summary>
    public partial class main : Window
    {
        private int MaxDBRows = 3;
        private int AmountOfRows;
        List<Classes.WeatherMessage> weathervalues = new List<Classes.WeatherMessage>();
        private int FormRefreshRate = 60;
        private int WheaterID = 1;
        private string LatestWeatherID;
        private DateTime RefreshTime;
        #region WheaterInfo
        const string APPID = "1b5d684d0770c40eccf2c841635621e2";
        string CityName = "Eindhoven";
        #endregion
        #region classes
        private Classes.WheaterAPI weatherAPI = new Classes.WheaterAPI();
        private Classes.WheaterAPI.root api = new Classes.WheaterAPI.root();
        private Classes.Database database = new Classes.Database();
        private Classes.Robot robot = new Classes.Robot();
        #endregion

        public main()
        {
            InitializeComponent();
            //Get Wheater and parse it into the labels
            api = weatherAPI.GetWheater(CityName, APPID);

            if (LatestWeatherID == null)
            {
                LatestWeatherID = weatherAPI.GetLatestWeatherID(database);
            }
            for (int i = 1; i <= Convert.ToInt32(LatestWeatherID); i++)
            {
                string[] ParameterNames = { i.ToString() };
                weathervalues.AddRange(database.GetQueryValue(Classes.Database.valueType.weatherMessage, Classes.Querry.Weather.GetLatest(), ParameterNames, Classes.Parameter.Weather.ID()).weatherList);
            }

            AmountOfRows = Convert.ToInt32(database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetAmountOfRows(), new string[0], new string[0]).value);

            #region UpdateForm
            UpdateForm(null, EventArgs.Empty);
            Timer timer = new Timer();
            timer.Interval = (FormRefreshRate * 6000);
            timer.Tick += new EventHandler(UpdateForm);
            timer.Start();
            #endregion

            if(AmountOfRows != 0 )
                UpdateGraphics();
        }
        #region UpdateMethods
        private void UpdateForm(object sender, EventArgs e)
        {
            UpdateWindow();
            SetIcon();
            UpdateDB();

            robot.CheckCheckIfRobotSprinkle(weathervalues, api);
        }
        private void UpdateWindow()
        {
            WhereLabel.Content = "Where: " + api.sys.country + " " + api.name;
            StatusLabel.Content = "Status: ";
            foreach (var wheatdisc in api.weather)
            {
                StatusLabel.Content += wheatdisc.description + ", ";
            }
            APITempLabel.Content = "Temperatuur: " + Convert.ToInt32(api.main.temp - 273) + "°C";
            APIHumLabel.Content = "Humidity: " + api.main.humidity + "%";
            APIPressLabel.Content = "Pressure: " + api.main.pressure + "hpa";
        }
        private void SetIcon()
        {
            WeatherIcon.Source = weatherAPI.GetIcon(api.weather[0].icon);
        }
        private void UpdateDB()
        {
            string CurrentDay;
            try
            {
                CurrentDay = database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetLatestDate(), new string[0], new string[0]).value;
            }
            catch
            {
                CurrentDay = "";
            }
            string today = DateTime.Today.ToString("M/d/yyyy") + " 00:00:00";
            if (CurrentDay == "" || CurrentDay != today)
            {
                weatherAPI.InsertWeather(CurrentDay, database, api, MaxDBRows, AmountOfRows);
                //omdat de er een nieuwe waarde is toegevoegd moet de lijngrafiek worden geupdate
                UpdateGraphics();
            }
        }
        private void UpdatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshTime = (DateTime)UpdatePicker.SelectedDate;
        }
        private void UpdateGraphics()
        {
            List<Line> lines = Classes.Draw.UpdateDrawings(AmountOfRows, weathervalues);
            foreach (Line line in lines)
            {
                mycanvas.Children.Add(line);
            }
        }
        #endregion
    }
}
