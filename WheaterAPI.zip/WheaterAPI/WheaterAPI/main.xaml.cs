﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net;
using System.Globalization;
using Newtonsoft.Json;

namespace WheaterAPI
{
    /// <summary>
    /// Interaction logic for main.xaml
    /// </summary>
    public partial class main : Window
    {
        private int MaxDBRows = 5;
        private int AmountOfRows;
        List<Classes.WeatherMessage> weathervalues = new List<Classes.WeatherMessage>();
        private int FormRefreshRate = 60;
        private string WeatherID;
        private DateTime RefreshTime;
        #region RobotVals
        private decimal Rtemp;
        private decimal Rhum;
        private double saltlevel;

        private string TempTopic = "PT12/csharp/Temp";
        private string HumTopic = "PT12/cshaprp/Hum";
        private string SaltTopic = "PT12/csharp/Salt";
        private string ActionTopic = "PT12/csharp/Action";

        private string DriveTopic = "PT12/arduino/Drive_controls";

        private int MaxProgressbar = 100;
        private int MinProgressbar = 0;
        #endregion
        #region WheaterInfo
        const string APPID = "1b5d684d0770c40eccf2c841635621e2";
        string CityName = "Eindhoven";
        #endregion
        #region classes
        private Classes.WheaterAPI weatherAPI = new Classes.WheaterAPI();
        private Classes.WheaterAPI.root api = new Classes.WheaterAPI.root();
        private Classes.Database database = new Classes.Database();
        private Classes.Robot robot = new Classes.Robot();
        private Classes.Draw draw = new Classes.Draw();
        private Classes.MQTT mqtt = new Classes.MQTT();
        #endregion

        public main(string userID)
        {
            InitializeComponent();

            mqtt.setup_mqtt_server("eijsenring.com", 1883);

            UpdateCB(userID);

            //Get Wheater and parse it into the labels
            api = weatherAPI.GetWheater(CityName, APPID);

            if (WeatherID == null)
            {
                WeatherID = weatherAPI.GetLatestWeatherID(database, userID);
            }
            for (int i = 1; i <= Convert.ToInt32(WeatherID); i++)
            {
                string[] ParameterNames = { i.ToString() };
                weathervalues.AddRange(database.GetQueryValue(Classes.Database.valueType.weatherMessage, Classes.Querry.Weather.GetLatest(), ParameterNames, Classes.Parameter.Weather.ID()).weatherList);
            }

            AmountOfRows = Convert.ToInt32(database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetAmountOfRows(), new string[0], new string[0]).value);
            SaltLevel.Maximum = MaxProgressbar;
            SaltLevel.Minimum = MinProgressbar;

            #region UpdateWindow
            UpdateForm(null, EventArgs.Empty);
            Timer timer = new Timer();
            timer.Interval = (FormRefreshRate * 6000);
            timer.Tick += new EventHandler(UpdateForm);
            timer.Start();
            #endregion
            #region UpdateRobotVals
            GetRobotValues(null, EventArgs.Empty);
            Timer Rtimer = new Timer();
            timer.Interval = (FormRefreshRate * 60);
            timer.Tick += new EventHandler(GetRobotValues);
            timer.Start();
            #endregion

            if(AmountOfRows != 0 )
                UpdateGraphics();
        }
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            /*Login LoginWindow = new Login();
            Application.Current.MainWindow = LoginWindow;
            LoginWindow.Show();
            Close();*/
        }
        #region UpdateMethods
        private void UpdateForm(object sender, EventArgs e)
        {
            UpdateAPIWindow();
            SetIcon();
            UpdateDB();
            if (WeatherID != "")
            {
                robot.CheckCheckIfRobotSprinkle(weathervalues, api);
            }
        }
        private void GetRobotValues(object sender, EventArgs e)
        {
            decimal message = Convert.ToDecimal(mqtt.Got_Message);
            if (mqtt.Got_Ontopic == TempTopic)
            {
                if (Rtemp != message)
                {
                    Rtemp = message;
                    UpdateRWindow();
                }
            }
            else if(mqtt.Got_Ontopic == HumTopic)
            {
                if(Rhum != message)
                {
                    Rhum = message;
                    UpdateRWindow();
                }
            }
            else if(mqtt.Got_Ontopic == SaltTopic)
            {
                double Smessage = Convert.ToDouble(mqtt.Got_Message);
                if(saltlevel != Smessage)
                {
                    saltlevel = Smessage;
                    UpdateRWindow();
                }
            }
        }
        private void UpdateAPIWindow()
        {
            WhereLabel.Content = "Where: " + api.sys.country + " " + api.name;
            StatusLabel.Content = "Status: ";
            foreach (var wheatdisc in api.weather)
            {
                StatusLabel.Content += wheatdisc.description + ", ";
            }
            APITempLabel.Content = "Temperature: " + Convert.ToInt32(api.main.temp - 273) + "°C";
            APIHumLabel.Content = "Humidity: " + api.main.humidity + "%";
            APIPressLabel.Content = "Pressure: " + api.main.pressure + "hpa";
        }
        private void UpdateRWindow()
        {
            RTempLabel.Content = Rtemp;
            RHumLabel.Content = Rhum;
            SaltLevel.Value = saltlevel;
        }
        private void SetIcon()
        {
            WeatherIcon.Source = weatherAPI.GetIcon(api.weather[0].icon);
        }
        private void UpdateDB()
        {
            string CurrentDay;
            try
            {
                CurrentDay = database.GetQueryValue(Classes.Database.valueType.String, Classes.Querry.Weather.GetLatestDate(), new string[0], new string[0]).value;
            }
            catch
            {
                CurrentDay = "";
            }
            string today = DateTime.Today.ToString("M/d/yyyy") + " 00:00:00";
            if (CurrentDay == "" || CurrentDay != today)
            {
                weatherAPI.InsertWeather(CurrentDay, database, api, MaxDBRows, AmountOfRows, WeatherID);                
                UpdateGraphics();
            }
        }
        private void UpdateGraphics()
        {
            if(WeatherID != "")
            {
                Classes.drawinglist objectlist = draw.UpdateDrawings(AmountOfRows, weathervalues);
                foreach (UIElement ob in objectlist.tempObjects)
                {
                    tempcanvas.Children.Add(ob);
                }
                foreach (UIElement ob in objectlist.humObjects)
                {
                    humcanvas.Children.Add(ob);
                }
                foreach (UIElement ob in objectlist.pressObjects)
                {
                    presscanvas.Children.Add(ob);
                }
            }
        }
        private void UpdateCB(string UserId)
        {
            RobotSelector.ItemsSource = robot.GetRobots(UserId);
            RobotSelector.SelectedValue = RobotSelector.Items[0];
        }
        #endregion

        private void driveB_Click(object sender, RoutedEventArgs e)
        {
            mqtt.send_message(DriveTopic, "#drive;");
        }
        private void returnB_Click(object sender, RoutedEventArgs e)
        {
            mqtt.send_message(DriveTopic, "#DRIVE;");
        }
    }
}
