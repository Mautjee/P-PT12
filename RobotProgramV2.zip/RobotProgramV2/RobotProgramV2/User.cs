﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotProgramV2
{
    class User
    {
        private int userID;
        private string username;
        private string password;

        public User(int userID)
        {
            this.userID = userID;
        }

        public void signIn(string usernameInput, string passwordInput)
        {
            //if username/password Input is the same as found in the database 
        }
    }
}
