﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotProgramV2
{
    class Salt
    {
        private int amountOfSalt;
        private int usedSalt;

        public Salt(int amountOfSalt, int usedSalt)
        {
            this.amountOfSalt = amountOfSalt;
            this.usedSalt = usedSalt;
        }

        public void calculateNewAmount()
        {
            amountOfSalt -= usedSalt;
        }

        public void updateDatabase()
        {
            //amountOfSalt to database
            //usedSalt to database
        }
    }
}
