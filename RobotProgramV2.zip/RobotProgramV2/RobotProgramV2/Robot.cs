﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotProgramV2
{
    class Robot
    {
        private string id;

        public Robot(string id)
        {
            this.id = id;
        }

        public void addUserToRobot(User newUser)
        {
            //database shit
        }
    }
}
